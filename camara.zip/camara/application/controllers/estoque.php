<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Estoque extends CI_Controller {

	public function __construct() {
		parent::__construct();
		init_sistema();
		$this -> load -> model('estoque_model', 'estoque');
		$this->load->library('cart');

	}

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index() {
		$this -> gerenciar();
	}


	public function gerenciar() {

		esta_logado();
		
		set_tema('headerinc',load_css(array('dataTables.bootstrap4')), FALSE);
		set_tema('footerinc', load_js(array('dataTables.bootstrap4','data-tables.min','table')), FALSE);
		set_tema('conteudo', load_modulo_sistema('view_gerente_estoque'));
		load_template();

	}

	public function zera_carrinho() {

		esta_logado();
		$this -> load -> library('cart');
		$this -> cart -> destroy();

	}

	public function lanca_carrinho() {

		esta_logado();

		$this -> form_validation -> set_rules('id', 'id', 'required|trim');
		$this -> form_validation -> set_rules('qty', 'quantidade', 'required|trim');
		$this -> form_validation -> set_rules('name', 'Descrição', 'required|trim');

		if ($this -> form_validation -> run() == TRUE) {

			$this -> load -> library('cart');
			
			//PÕE UM PREÇO ZERADO CASO AINDA NÃO TENHA PREÇO
			$price = ($this->input->post('price') == '')? 0.00 : $this->input->post('price');
			
			//Trata a grade caso o produto não tenha
			$grade = ($this -> input -> post('id_grade') == '') ? 0 : $this -> input -> post('id_grade');

			$data = array('id' => $this -> input -> post('id'), 
						  'qty' => $this -> input -> post('qty'), 
						  'price' => $this -> input -> post('price'), 
						  'name' => $this -> input -> post('name'), 
						  'options' => array('grade' => $grade));

			//insere no carrinho
			$this -> cart -> insert($data);
		} else {
			set_msg('msgerror', 'ERRO AO LANÇAR O PRODUTO', 'error');
		}

	}

	public function lancamento_de_estoque() {

		esta_logado();
		
		
		
		
		$this -> load -> library('cart');

		//TRATA OS DADOS COM O ID DO FORNECEDOR, TIPO DE PROCESSO (ENTRADA, SAÍDA), NUMERO DA NOTA

		$fornecedor = explode('-', $this -> input -> post('fornecedor'));
		$tipo = $this -> input -> post('tipo');

		//DIRECIONA PARA O ESTOQUE DE ACORDO COM O TIPO DE PROCESSO

		if (!empty($tipo) && $tipo === 'E') {//PARA ENTRADA

			if ($this -> cart -> total_items() < 1) {
				set_msg('msgerror', 'Não há itens para lançamento no estque', 'error');
				redirect(current_url());
			}

			foreach ($this->cart->contents() as $items) :

				//RETORNA O ID DO PRODUTO PELO CODIGO DE BARRA
				$produto = $this -> estoque -> get_produto($this -> session -> userdata('user_id_empresa'), $items['id']) -> row();

				foreach ($this->cart->product_options($items['rowid']) as $option_name => $option_value) {

					//VERIFICA SE JÁ EXISTE O ITEM NO ESTOQUE COM MESMA GRADE, E DIRECIONA PARA UM UP OU INSERT
					$num_item = $this -> estoque -> get_byLinhas($produto -> id, $option_value);

					$dados['id_grade'] = $option_value;
				}

				//Banco de dados do lançamento
				$banco = 'lancamento';

				//Insert o registro de lançamento
				$dados['status'] = 'A';
				$dados['subtotal'] = $items['subtotal'];
				$dados['id_produto'] = $produto -> id;
				$dados['id_fornecedor'] = $fornecedor[0];
				$dados['quantidade'] = $items['qty'];
				$dados['numero_nota'] = $this -> input -> post('numero_nota');
				$dados['id_empresa'] = $this -> session -> userdata('user_id_empresa');

				//Insere no banco dados de lançamento: array de dados, banco, tipo, redirect
				$this -> estoque -> gerenciar_estoque($dados, TRUE, $banco, FALSE);

				//Dados do estoque

				$banco = 'estoque';
				//Insert o registro no estoque
				$data['marca'] = 'N';
				$data['status'] = 'A';
				$data['codigo_barra'] = $items['id'];
				$data['id_produto'] = $produto -> id;
				$data['id_grade'] = $option_value;
				$data['quantidade'] = $items['qty'];
				$data['id_empresa'] = $this -> session -> userdata('user_id_empresa');
				
				
				//Gerenciamento do estoque
				
				if ($num_item -> num_rows() < 1) {
					//insert no estoque, caso não exista
					$this -> estoque -> gerenciar_estoque($data, TRUE, $banco, FALSE);

				} else {

					$dataup['quantidade'] = $items['qty'] + $num_item -> row('quantidade');
					//Update caso já exista, acrescenta no estoque
					$this -> estoque -> gerenciar_estoque($dataup, FALSE, $banco, FALSE, array('id_produto' => $produto -> id, 'id_grade' => $option_value));

				}

			endforeach;
			redirect(current_url());
		}

		set_tema('headerinc', load_css(array('jquery-ui')), FALSE);
		set_tema('conteudo', load_modulo_sitestema('view_nota_fiscal_nova', 'home'));
		set_tema('footerinc', load_js(array('jquery-ui.min', 'autoComplete', 'insere-grade')), FALSE);
		load_template();

	}

	public function get_fornecedor($filtro = NULL) {

		esta_logado();

		$fornecedores = $this -> estoque -> get_fornecedor($this -> session -> userdata('user_id_empresa'), $filtro) -> result();

		echo json_encode($fornecedores);

	}

	public function get_produto($filtro = NULL) {

		esta_logado();

		$produto = $this -> estoque -> get_produto($this -> session -> userdata('user_id_empresa'), $filtro) -> result();

		echo json_encode($produto);

	}

	public function gerenciar_notas_fiscais() {

		esta_logado();

		set_tema('headerinc', load_css(array('dataTables.foundation.min')), FALSE);
		set_tema('footerinc', load_js(array('delete-message', 'jquery.dataTables.min', 'dataTables.foundation.min', 'table')), FALSE);
		set_tema('conteudo', load_modulo_sitestema('view_nota_fiscal_gerente', 'home'));
		load_template();

	}
	
	
	public function lanca_estoques(){
		
	$estoque = $this->db->get_where('produto',array('codigo_barra !='=>''))->result();

	$dado['marca'] = 'N';
	$dado['status'] = 'A';
	$dado['id_empresa'] = '3';
	$dado['id_grade'] = '1';
	
	foreach($estoque as $pro){
		$dado['id_produto'] = $pro->id;
		$dado['quantidade'] = 30;
		$dado['codigo_barra'] =  $pro->codigo_barra;
		
		$this->db->insert('estoque',$dado);
	}
	
	}

	//Excluir perfil
	public function deletar($id = '') {

		esta_logado();

		if ($id != NULL) :

			$query = $this -> empresa -> get_byid($id, $this -> session -> userdata('user_id_empresa'));

			if ($query -> num_rows() == 1) :

				$query = $query -> row();

				if ($query -> id !== 1) :

					//excluir
					$this -> empresa -> do_delete(array('id' => $query -> id));
				else :
					set_msg('msgerror', 'Este registro não pode ser excluído', 'warning');
				endif;
			else :
				set_msg('msgerror', 'Registro não encontrado para a exclusão', 'warning');
			endif;
		else :
			set_msg('msgerror', 'Escolha um resgistro para ser excluído', 'warning');
		endif;

		redirect('empresa/gerenciar_classe_contabil');

	}

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
