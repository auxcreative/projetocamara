<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Prestacao_de_contas extends CI_Controller {
	
    public function __construct(){
		parent::__construct();
		init_site();

    }

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->getItem();
	}
	
	public function getItem($cod = null){
		
		$this->load->model('crud_model');
		
		if($cod == null){ //Select de todas tuplas 
			$parametrosItem = array(
				"distinct"=>FALSE,
	            "select" => "*",
	            "table" => "xon_transparencia",
	            "where" => "",
	            "order_by" => "",
	            "like" => "",
	            "limit" => "",
	            "group_by" => "",
	            "join" => ""
	        );
			
			//Obem matriz com os dados
			$dadosItem = $this->crud_model->select($parametrosItem);
			
			if($dadosItem) {
			//carrega view com os dados buscados
			$dados['ano'] = $dadosItem;
			set_tema('conteudo', load_modulo_site('view_prestacao_de_contas', $dados));
			load_template();
				
				
			} else {
				//carrega view informando que não há dados a serem exibidos
			}
			
		} else { //Select de tupla específica
			
			$parametrosItem = array(
				"distinct"=>FALSE,
	            "select" => "*",
	            "table" => "xon_menu",
	            "where" => array('id' => $cod),
	            "order_by" => "",
	            "like" => "",
	            "limit" => "",
	            "group_by" => "",
	            "join" => ""
        	);
		
		//Obem matriz com os dados
		$dadosItem = $this->crud_model->select($parametrosItem);
		
		if($dadosItem) {
				//carrega view com os dados buscados
				
			} else {
				//carrega view informando que não há dados a serem exibidos para a consulta
				
			}
		}
		
	}

	public function mesa_diretora($cod = null){		
		$this->load->model('crud_model');
		
		if($cod == null){ //Select de todas tuplas 
			$parametrosItem = array(
			    "distinct"=>TRUE,
	            "select" => "ano",
	            "table" => "xon_transparencia",
	            "where" => "",
	            "order_by" => "",
	            "like" => "",
	            "limit" => "",
	            "group_by" => "",
	            "join" => ""
	        );
			
			//Obem matriz com os dados
			$dadosItem = $this->crud_model->select($parametrosItem);
			
			if($dadosItem) {
			//carrega view com os dados buscados
			$dados['ano'] = $dadosItem;
			set_tema('conteudo', load_modulo_site('view_prestacao_de_contas_mesa_diretora', $dados));
			load_template();
				
				
			} else {
				//carrega view informando que não há dados a serem exibidos
			}
			
		} else { //Select de tupla específica
			
			$parametrosItem = array(
				"distinct"=>TRUE,			
	            "select" => "ano",
	            "table" => "xon_transparencia",
	            "where"=>"",
	            "order_by" => "",
	            "like" => "",
	            "limit" => "",
	            "group_by" => "",
	            "join" => ""
        	);
        	
			$parametrosFiltro = array( //Select com filtro especifico	
				"distinct"=>FALSE,		
	            "select" => "*",
	            "table" => "xon_transparencia",
	            "where" => array('ano' => $cod),
	            "order_by" => "",
	            "like" => "",
	            "limit" => "",
	            "group_by" => "",
	            "join" => ""
        	);
		
		//Obem matriz com os dados
		$dadosItem = $this->crud_model->select($parametrosItem);
		$dadosFiltro = $this->crud_model->select($parametrosFiltro);
			
		
		if($dadosItem) {
				//carrega view com os dados buscados
							//carrega view com os dados buscados
			$dados['ano'] = $dadosItem;
			$dados['mes'] = $dadosFiltro;
			set_tema('conteudo', load_modulo_site('view_prestacao_de_contas_mesa_diretora', $dados));
			load_template();
				
			} else {
				//carrega view informando que não há dados a serem exibidos para a consulta
				
			}
		}
		
	}

	public function vereadores($cod = null, $id_vereador=null){		
		$this->load->model('crud_model');
		
		if($cod == null && $id_vereador==null){ //Select de todas tuplas 

		$parametrosItem = array(
				"distinct"=>TRUE,			
	            "select" => "ano",
	            "table" => "xon_transparencia",
	            "where"=>"",
	            "order_by" => "",
	            "like" => "",
	            "limit" => "",
	            "group_by" => "",
	            "join" => ""
        	);
			
			$parametrosFiltro = array( //Select com filtro especifico	
				"distinct"=>FALSE,		
	            "select" => "*",
	            "table" => "xon_transparencia",
	            "where" => array('ano' => $cod),
	            "order_by" => "",
	            "like" => "",
	            "limit" => "",
	            "group_by" => "",
	            "join" => ""
        	);
		
		$parametrosContas = array( //Select com filtro especifico	
				"distinct"=>TRUE,		
	            "select" => "ano,mes,",
	            "table" => "xon_transparencia",
	            "where" => array('ano' => $cod),
	            "order_by" => "",
	            "like" => "",
	            "limit" => "",
	            "group_by" => "",
	            "join" => ""
        	);        				
			
			//Obem matriz com os dados
			$dadosItem = $this->crud_model->select($parametrosItem);
			$dadosFiltro = $this->crud_model->select($parametrosFiltro);
			$dadosContas = $this->crud_model->select($parametrosContas);
			
			if($dadosItem) {
			//carrega view com os dados buscados
			$dados['ano'] = $dadosItem;//Lista os ano do menu
			$dados['mes'] = $dadosFiltro;//Lista os anos das contas
			
			set_tema('conteudo', load_modulo_site('view_prestacao_de_contas_vereadores', $dados));
			load_template();
				
				
			} else {
				//carrega view informando que não há dados a serem exibidos
							//carrega view com os dados buscados
			$dados['mes_vereador'] = $dadosItem;
			set_tema('conteudo', load_modulo_site('view_prestacao_de_contas_vereadores', $dados));
			load_template();
			}
			
		} else { //Select de tupla específica
			
			$parametrosItem = array(
				"distinct"=>TRUE,			
	            "select" => "ano",
	            "table" => "xon_transparencia",
	            "where"=>"",
	            "order_by" => "",
	            "like" => "",
	            "limit" => "",
	            "group_by" => "",
	            "join" => ""
        	);
			
			$parametrosVereador = array( //Select com filtro especifico	
				"distinct"=>TRUE,		
	            "select" => "*",
	            "table" => "xon_vereador",
	            "where" => "",
	            "order_by" => "",
	            "like" => array("legislatura"=>$cod),
	            "limit" => "",
	            "group_by" => "",
	            "join" => ""
        	);
        	
			$parametrosFiltro = array( //Select com filtro especifico	
				"distinct"=>FALSE,		
	            "select" => "*",
	            "table" => "xon_vereado",
	            "where" => "",
	            "order_by" => "",
	            "like" => "",
	            "limit" => "",
	            "group_by" => "",
	            "join" => ""
        	);
		
		//Obem matriz com os dados
		$dadosItem = $this->crud_model->select($parametrosItem);
		$dadosFiltro = $this->crud_model->select($parametrosVereador);
			
		
		if($dadosItem) {
				//carrega view com os dados buscados
							//carrega view com os dados buscados
			$dados['ano'] = $dadosItem;
			$dados['vereador'] = $dadosFiltro;
			set_tema('conteudo', load_modulo_site('view_prestacao_de_contas_vereadores', $dados));
			load_template();
				
			} else {
				//carrega view informando que não há dados a serem exibidos para a consulta
				
			}
		}
		
	}
	

	
	
}


/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */