<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Noticias extends CI_Controller {

    public function __construct(){
        parent::__construct();
        init_main();
        
    }
	/**
	 * X-On
	 * Sistema: Portal da Transparencia - Coelho Neto
	 * Controlador: noticias
	 */
	public function index()	{
		
	$dados['noticias'] = $this->getItem();
	$dados['pagina'] = 'noticias';
        
	set_tema('conteudo', load_modulo_main('noticias', $dados));
    	load_template();
	}
	
	public function getItem($cod = null){
		
		$this->load->model('crud_model');
		
		if($cod == null){ //Select de todas tuplas 
			$parametrosItem = array(
				"distinct" =>null,
	            "select" => "*",
	            "table" => "xon_noticias",
	            "where" => "",
	            "order_by" => "id desc",
	            "like" => "",
	            "limit" => "",
	            "group_by" => "",
	            "join" => ""
	        );
			
		//Obem matriz com os dados
		$dadosItem = $this->crud_model->select($parametrosItem);
			
			if($dadosItem) {
				return $dadosItem;
			} else {
				return array();
			}
			
		} else { //Select de tupla específica
			
			$parametrosItem = array(
				"distinct"=>null,
	            "select" => "*",
	            "table" => "xon_noticias",
	            "where" => array('id' => $cod),
	            "order_by" => "",
	            "like" => "",
	            "limit" => "",
	            "group_by" => "",
	            "join" => ""
        	);
		
		//Obem matriz com os dados
		$dadosItem = $this->crud_model->select($parametrosItem);
		
		if($dadosItem) {
				return $dadosItem;
			} else {
				return array();
			}
		}
		
	}
	

	public function removerItem($cod = null){
		
		if($cod != null) {
                    $cod = decodificarString($cod);
			$this->load->model('crud_model');
			
			$result = $this->crud_model->delete("xon_noticias", "id", array("id" => $cod));
			if($result) {
				if($result['code'] == 0) {//Query executada com sucesso
					//Carrega proxima view
					set_msg('notificacao', 'Notícia removida com sucesso', 'success');
                                        redirect("main/noticias");
				} else {
					//Carrega proxima view enviando erro para depuração  (array $result)
					set_msg('notificacao', 'Falha ao remover notícia');
				}
			}
		} else {
			//redireciona informando que um item precisa ser selecionado para remoção
		}
	}
	
	public function adicionarNoticia() {
		
		$dados['pagina'] = "nova_noticia";
		
		
		
		set_tema('tinymce', load_js(array('plugins/tinymce/tinymce.min','tinyMCE')), FALSE);
		set_tema('conteudo', load_modulo_main($dados['pagina'], $dados));
    	load_template();
	}
	
	public function editarNoticia($cod = null){
		
		if($cod != null) {
			
		$this->form_validation->set_rules('p#titulo','Título','required|trim');
			
		if($this->form_validation->run()){
			
			setItem($cod,"xon_noticias",$_POST, "main/noticias");
			
		} else {
			
		$dados['pagina'] = "editar_noticia";		
		$dados['noticia'] = $this->getItem(decodificarString($cod));
		
		set_tema('tinymce', load_js(array('plugins/tinymce/tinymce.min','tinyMCE')), FALSE);
		set_tema('conteudo', load_modulo_main($dados['pagina'], $dados));
        load_template();
		
		} 
	}
        	
}
}