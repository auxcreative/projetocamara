<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Fornecedor extends CI_Controller {
	
    public function __construct(){
		parent::__construct();
		init_sistema();
		$this->load->model('fornecedor_model','fornecedor');

    }

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->gerenciar();
	}
	
	public function get_cidade(){
		
		esta_logado();
			
		$variable = $this->fornecedor->get_bycidade()->result();
		
		echo json_encode($variable);
	}
	
	public function gerenciar(){
		
		esta_logado();

		 	set_tema('headerinc', load_js(array('foundation.alerts')), FALSE);
			set_tema('footerinc', load_js(array('delete-message','jquery.dataTables.min','dataTables.foundation.min','table')), FALSE);
         	set_tema('conteudo', load_modulo_sitestema('view_fornecedor_gerente', 'home'));
         	load_template();		
		
	}
	
	public function novo(){
		
		esta_logado();
		
		$this->form_validation->set_rules('razao','Razão','required|trim|strtoupper');
		$this->form_validation->set_rules('fantasia','Fantasia','trim|strtoupper');
		$this->form_validation->set_rules('id_tipo','Tipo','trim|required');
		$this->form_validation->set_rules('id_uf','UF','trim|required');
		$this->form_validation->set_rules('cnpj','CNPJ','trim');
		$this->form_validation->set_rules('inscricao_estadual','Inscrição Estadual','trim');
		$this->form_validation->set_rules('logradouro','Logradouro','trim|strtoupper');
		$this->form_validation->set_rules('numero','numero','trim|strtoupper');
		$this->form_validation->set_rules('bairro','Bairro','trim|strtoupper|required');
		$this->form_validation->set_rules('cidade','Cidade','trim|strtoupper|required');
		$this->form_validation->set_rules('complemento','Complemento','trim|strtoupper');
		$this->form_validation->set_rules('email','email','trim|strtolower');
		$this->form_validation->set_rules('telefone','Telefone','trim');
		$this->form_validation->set_rules('cep','CEP','trim');
		$this->form_validation->set_rules('celular_representante','Fantasia','trim');
		$this->form_validation->set_rules('representante','representante','trim|strtoupper');
		
		if($this->form_validation->run() == TRUE){
			
			$dados = elements(array('razao','fantasia','status','cnpj','logradouro','id_tipo',
									'bairro','id_uf','numero','cidade','complemento','email',
									'telefone','celular_representante','representante','cep','inscricao_estadual'),
									$this->input->post());
											
			$dados['id_empresa'] = $this->session->userdata('user_id_empresa');
			
			$this->fornecedor->do_insert($dados, TRUE);
		}
		set_tema('headerinc', load_css(array('jquery-ui')), FALSE);
		set_tema('footerinc', load_js(array('maskedinput','mascaras-all','jquery-ui','autoComplete')), FALSE);
        set_tema('conteudo', load_modulo_sitestema('view_fornecedor_novo', 'home'));
        load_template();
	
	}
	
	public function editar(){
		
		esta_logado();
		
		$this->form_validation->set_rules('razao','Razão','required|trim|strtoupper');
		$this->form_validation->set_rules('fantasia','Fantasia','trim|strtoupper');
		$this->form_validation->set_rules('id_tipo','Tipo','trim|required');
		$this->form_validation->set_rules('id_uf','UF','trim|required');
		$this->form_validation->set_rules('cnpj','CNPJ','trim');
		$this->form_validation->set_rules('inscricao_estadual','Inscrição Estadual','trim');
		$this->form_validation->set_rules('logradouro','Logradouro','trim|strtoupper');
		$this->form_validation->set_rules('numero','numero','trim|strtoupper');
		$this->form_validation->set_rules('bairro','Bairro','trim|strtoupper|required');
		$this->form_validation->set_rules('cidade','Cidade','trim|strtoupper|required');
		$this->form_validation->set_rules('complemento','Complemento','trim|strtoupper');
		$this->form_validation->set_rules('email','email','trim|strtolower');
		$this->form_validation->set_rules('telefone','Telefone','trim');
		$this->form_validation->set_rules('cep','CEP','trim');
		$this->form_validation->set_rules('celular_representante','Fantasia','trim');
		$this->form_validation->set_rules('representante','representante','trim|strtoupper');
		
		if($this->form_validation->run()== TRUE){
		
			$dados = elements(array('razao','fantasia','status','cnpj','logradouro','id_tipo',
									'bairro','id_uf','numero','cidade','complemento','email',
									'telefone','celular_representante','representante','cep','inscricao_estadual'),
									$this->input->post());
										
			
			$this->fornecedor->do_update($dados, array('id'=>$this->input->post('id'),'id_empresa'=>$this->input->post('id_empresa')), TRUE);
		}
		
		set_tema('headerinc', load_js(array('foundation.alerts')), FALSE);
		set_tema('footerinc', load_js(array('maskedinput','jquery-ui','autoComplete','mascaras-all')), FALSE);
        set_tema('conteudo', load_modulo_sitestema('view_fornecedor_editar', 'home'));
        load_template();
	
	}	

	public function gerenciar_classe_contabil(){
		
		esta_logado();
		
		set_tema('headerinc', load_css(array('dataTables.foundation.min')), FALSE);
		set_tema('footerinc', load_js(array('delete-message','jquery.dataTables.min','dataTables.foundation.min','table')), FALSE);		
        set_tema('conteudo', load_modulo_sitestema('view_empresa_gerente_classeContabil', 'home'));
        load_template();
		
		
	}	

	//Excluir perfil
	public function deletar($id='') {

		esta_logado();

		if ($id != NULL) :

			$query = $this -> fornecedor -> get_byid($id, $this->session->userdata('user_id_empresa'));

			if ($query -> num_rows() == 1) :

				$query = $query -> row();
				
				if ($query -> id !== 1) :
										
					//excluir
					$this->fornecedor->do_delete(array('id'=>$query->id));
					
				else :
					set_msg('msgerror', 'Este registro não pode ser excluído', 'warning');
				endif;
			else :
				set_msg('msgerror', 'Registro não encontrado para a exclusão', 'warning');
			endif;
		else :
			set_msg('msgerror', 'Escolha um resgistro para ser excluído', 'warning');
		endif;

		redirect('fornecedor/gerenciar');

	}	
	
}


/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */