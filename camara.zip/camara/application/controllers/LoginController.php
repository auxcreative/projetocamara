<?php

/**
* Controlador - Login
* X-On Sistemas
*/
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

Class LoginController extends CI_Controller {
	
    private $loginUsuario;
    private $senhaUsuario;
    private $dadosAutenticados;
    
        public function __construct(){
        parent::__construct();
        $CI = &get_instance();
        $CI -> load -> library(array('sistema', 'session', 'form_validation', 'parser'));
        $CI -> load -> helper(array('form', 'url', 'array', 'text', 'html', 'date'));
        set_tema('template', 'loginpage');
        set_tema('headerinc', load_css(array('ckeditor.samples','bootstrap.min','sb-admin','font-awesome/css/font-awesome', 'app','dataTables.bootstrap','dataTables.responsive')), FALSE);
        //init_main();		
    }

    public function index()     {
        $dados['pagina'] = 'loginpage';
	set_tema('conteudo', load_modulo_main('loginpage', $dados));
        load_template();
    }
	
	/** Obtem usuario  */
    public function setAcesso($loginUsuario){
        $this->loginUsuario = $loginUsuario;
    }

    /** Obtem senha  */
    public function setSenha($senhaUsuario){
        $this->senhaUsuario = $senhaUsuario;
    }
  
    private function validaAutenticacaoAcesso()  {
        // Verifica dados informados
		
        if ($this->loginUsuario && $this->senhaUsuario){
        	
            $parametros = array(
                "select" => "*",
                "table" => "xon_usuario",
                "where" => array("login" => $this->anti_injection($this->loginUsuario),
                                   "senha" => $this->senhaUsuario),
                "order_by" => "",
                "like" => "",
                "limit" => "",
                "group_by" => "",
                "join" => ""
            );

            // Carrega dados
            $this->load->model('crud_model');
            $dadosAutenticados = $this->crud_model->select($parametros);
            
            if ($dadosAutenticados){

               return $dadosAutenticados; 
            }
            
        }
    }
    
    // remove palavras que contenham sintaxe sql
    private function anti_injection($sqlinj)
    {
        $sqlinj = preg_replace("/(from|select|insert|delete|where|drop table|show tables|#|'|´|\*|--|\\\\)/i", '', $sqlinj);
        $sqlinj = trim($sqlinj); //limpa espaços vazio
        $sqlinj = strip_tags($sqlinj); //tira tags html e php
        return $sqlinj;
    }

    public function autenticacao()    {
	
	$this->setAcesso($_POST['loginUsuario']);
	$this->setSenha(sha1($_POST['senhaUsuario']));

	$dados = $this->validaAutenticacaoAcesso();
		
        if ($dados) {
            $dados = array(
                'nomeUsuario' => $dados[0]->nome,
                'user_logado' => true
            );
            
            $CI = &get_instance();
            $CI -> load -> library('session');
            $CI -> session -> set_userdata($dados);
			
						                             
            print "<script>window.location = '".base_url('main/home')."'</script>";
        }
        else {
            print "USUÁRIO E/OU SENHA INCORRETOS";
        }
    }
    
    public function fecharSessao($codNoti,$baseUrl){
		/* Encerra a sessão */
		@session_start();
		$_SESSION = array(); 			 
		session_destroy();

                set_msg('notificacao', 'Sessão encerrada com sucesso', 'success');
                redirect("../loginController");
		
    }
}
