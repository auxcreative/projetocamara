
                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           <i class="fa fa-plus"></i> Nova Notícia <small></small>                            
                        </h1>
                        <ol class="breadcrumb">
                            <li class="active">
                                <i class="fa fa-newspaper-o"></i> Nova notícia
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->
				<!-- AREA DE NOTIFICAÇÃO -->
                
                
                
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-12">
                    	
                        <div class="panel panel-default">
                            <div class="panel-body">
                                <div class="container-fluid">
                               	<form action="<?php echo current_url(); ?>" method="POST" class="form-group">
                               
                               	<div class="row">
                                <div class="col-lg-12">
                                	<div class="form-group">
                                            <label>Titulo: </label>
                                            <input class="form-control" required  name="p#titulo" placeholder="">
                                    </div>
                                </div>
                                </div>
                                <div class="row">
                                <div class="col-lg-9">
                                	<div class="form-group">
                                            <label>Slug: </label>
                                            <input class="form-control" required  name="p#slug" placeholder="">
                                    </div>
                                	<div class="form-group">
                                            <label>Resumo:</label>
                                            <textarea name="resumo" class="form-control" rows="3">
											</textarea>
                                    </div>                          
                                </div>
                                <div class="col-lg-3">
                                        <div class="form-group">
                                            <label>Publicado?:</label>
                                            <div class="radio">
                                                <label>
                                                    <input type="radio" name="p#status" value="n" checked>Não Publicado
                                                </label>
                                            </div>
                                            <div class="radio">
                                                <label>
                                                    <input type="radio" name="p#status" value="p">Publicado
                                                </label>
                                            </div>
                                		</div>
                                </div>
                                </div>
                                <div class="row">
                                <div class="col-lg-3">
                                        <div class="form-group">
                                            <label>Publicado?:</label>
                                            <div class="radio">
                                                <label>
                                                    <input type="radio" name="p#status" value="n" checked>Não Publicado
                                                </label>
                                            </div>
                                            <div class="radio">
                                                <label>
                                                    <input type="radio" name="p#status" value="p">Publicado
                                                </label>
                                            </div>
                                		</div>
                                </div>
                                </div>
                                <div class="row">
                                <div class="col-lg-12">
                                	<div class="form-group">
                                            <label>Texto da Notícia:</label>
                                            <textarea name="p#texto" class="form-control" id="editor" rows="4">
											</textarea>
                                    </div>
                                <button type="submit" class="btn btn-default"><i class="fa fa-check"></i> Cadastrar Notícia</button>
                                </div>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                            </form>
                            </div>
                            <!-- /.row (nested) -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->



