
                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           <i class="fa fa-calendar"></i> Agenda <small></small>
                            <button class="btn btn-primary btn-lg" style="float: right"><i class="fa fa-plus"></i> Novo Compromisso</button>
                        </h1>
                        <ol class="breadcrumb">
                            <li class="active">
                                <i class="fa fa-calendar"></i> Agenda
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->
				<!-- AREA DE NOTIFICAÇÃO -->
                
                
                
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-body">
                                <div class="dataTable_wrapper">
                                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                        <thead>
                                            <tr>
                                            	<th width="">Evento</th>
                                                <th width="10%">Data</th>
                                                <th width="4%">Hora</th>
                                                <th width="10%">Status</th>
                                                <th width="5%">Atividade</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php foreach($agenda as $evento): ?>
                                            <tr>
                                                <td><?php print $evento->evento; ?></td>
                                                <td><?php print $evento->data; ?></td>
                                                <td><?php print $evento->hora; ?></td>
                                                <td><?php print $evento->status; ?></td>
                                                <td>
                                                	<div class="text-right">
		                                            	<a class="btn btn-danger" alt="Excluir"><i class="fa fa-search"></i> Consultar</a>
		                                            </div>
                                                </td> 
                                            </tr>
                                       	<?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
                <script>
				    $(document).ready(function() {
				        $('#dataTables-example').DataTable({
				                responsive: true
				        });
				    });
			    </script>