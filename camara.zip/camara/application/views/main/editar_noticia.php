
                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           <i class="fa fa-edit"></i> Editar Notícia <small></small>
                            
                        </h1>
                        <ol class="breadcrumb">
                            <li class="active">
                                <i class="fa fa-edit"></i> Editar notícia
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->
				<!-- AREA DE NOTIFICAÇÃO -->
                
                
                
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-body">
                                <div class="row">
                                    <form action="<?php echo current_url(); ?>/<?php print codificarString($noticia[0]->id); ?>" method="POST">
                                <div class="col-lg-12">
                                	<div class="form-group">
                                            <label>Titulo: </label>
                                            <input class="form-control" required  name="p#titulo" placeholder="" value="<?php print $noticia[0]->titulo; ?>">
                                     </div>
                                </div>
                                <div class="col-lg-9">
                                	<div class="form-group">
                                            <label>Slug: </label>
                                            <input class="form-control" required  name="p#slug" placeholder="" value="<?php print $noticia[0]->slug; ?>">
                                     </div>
                                	<div class="form-group">
                                            <label>Resumo:</label>
                                            <textarea name="resumo" class="form-control" <?php ?> rows="3"></textarea>
                                    </div>                          
                                </div>
                                <div class="col-lg-3">
                                        <div class="form-group">
                                            <label>Publicado?:</label>
                                            <div class="radio">
                                                <label>
                                                    <input type="radio" name="p#status" value="n"
                                                    <?php
                                                    if($noticia[0]->status == 'n'){
                                                    	print " checked='checked'";
                                                    }
                                                     ?>
                                                    >Não Publicado
                                                </label>
                                            </div>
                                            <div class="radio">
                                                <label>
                                                    <input type="radio" name="p#status" value="p"
                                                    <?php
                                                    if($noticia[0]->status == 'p'){
                                                    	print " checked='checked'";
                                                    }
                                                     ?>
                                                    >Publicado
                                                </label>
                                            </div>
                                		</div>
                                </div>
                                <div class="col-lg-12">
                                	<div class="form-group">
                                            <label>Texto da Notícia:</label>
                                            <textarea name="p#texto" class="form-control" id="editor" rows="6">
                                            <?php print $noticia[0]->texto; ?>
											</textarea>
                                    </div>
                                <button type="submit" class="btn btn-default"><i class="fa fa-check"></i> Atualizar</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                            </form>
                            </div>
                            <!-- /.row (nested) -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->



