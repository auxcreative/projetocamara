
                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           <i class="fa fa-flag"></i> Partidos <small></small>
                            <button class="btn btn-primary btn-lg" style="float: right"><i class="fa fa-plus"></i> Novo Partido</button>
                        </h1>
                        <ol class="breadcrumb">
                            <li class="active">
                                <i class="fa fa-newspaper-o"></i> Partidos
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->
				<!-- AREA DE NOTIFICAÇÃO -->
                
                
                
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-hover table-striped">
                                        <thead>
                                            <tr>
                                            	<th width="">Imagem</th>
                                                <th width="">Nome</th>
                                                <th width="">Sigla</th>
                                                <th width="">Status</th>
                                                <th width="">Ações</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php foreach($partidos as $partido): ?>
                                            <tr>
                                                <td><?php print $partido->imagem; ?></td>
                                                <td><?php print $partido->nome; ?></td>
                                                <td><?php print $partido->sigla; ?></td>
                                                <td><?php print $partido->status; ?></td>
                                                <td>
                                                	<div class="text-right">
		                                            	<a class="btn btn-success alert-dropdown" alt="Publicar/Despublicar"><i class="fa fa-power-off"></i></a>
		                                            	<a class="btn btn-primary" alt="Editar"><i class="fa fa-pencil"></i></a>
		                                            	<a class="btn btn-danger" alt="Excluir"><i class="fa fa-trash"></i></a>
		                                            </div>
                                                </td>
                                            </tr>
                                       	<?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->



