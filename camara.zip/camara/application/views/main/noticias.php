
                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            
                           <i class="fa fa-newspaper-o"></i> Notícias <small>Artigos, posts, notícias</small>
                            <a href="<?php print base_url('main/noticias/adicionarNoticia'); ?>" class="btn btn-primary btn-lg" style="float: right"><i class="fa fa-plus"></i> Nova Notícia</a>
                        </h1>
                        <ol class="breadcrumb">
                            <li class="active">
                                <i class="fa fa-newspaper-o"></i> Notícias
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row --> 
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-12"> 
                        <div class="panel panel-default">
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-hover table-striped">
                                        <thead>
                                            <tr>
                                            	<th width="15%">Data da Publicação</th>
                                                <th width="65%">Título</th>
                                                <th width="5%">Status</th>
                                                <th width="15%">Ações</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php foreach($noticias as $noticia): ?>
                                            <tr>
                                                <td><?php print $noticia->data_inc; ?></td>
                                                <td><?php print $noticia->titulo; ?></td>
                                                <td><?php print $noticia->status; ?></td>
                                                <td>
                                                	<div class="text-right">

                                                                <a href="noticias/editarNoticia/<?php print codificarString($noticia->id) ?>" class="btn btn-primary" alt="Editar" data-toggle="tooltip" title="Editar"><i class="fa fa-pencil"></i></a>
                                                                <a href="noticias/removerItem/<?php print codificarString($noticia->id) ?>" class="btn btn-danger" alt="Excluir" data-toggle="tooltip" title="Remover"><i class="fa fa-trash"></i></a>
		                                            </div>
                                                </td>
                                            </tr>
                                       	<?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
               


