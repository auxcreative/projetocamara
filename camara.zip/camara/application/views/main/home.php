
                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           <i class="fa fa-newspaper-o"></i> xPanel - Início <small></small>
                            <a href="?/main/Noticias/adicionarNoticia" class="btn btn-primary btn-lg" style="float: right"><i class="fa fa-plus"></i> Nova Notícia</a>
                        </h1>
                        <ol class="breadcrumb">
                            <li class="active">
                                <i class="fa fa-newspaper-o"></i> Início
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row --> 
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-12"> 
                        <div class="panel panel-default">
                            <div class="panel-body">
                                <div class="table-responsive">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
               


