<?php
if (!defined('BASEPATH'))exit('No direct script access allowed');?>
<div class="container">
<div class="col-md-12  login">
<div class="row">
<div class="col-md-10 col-md-offset-1">
<div class="row"><?php echo breadcrumb(); ?></div>

<div class="row">
  <div class="btn-group" role="group" aria-label="...">Lançar</div>
  <div class="btn-group" role="group" aria-label="...">...</div>
  <div class="btn-group" role="group" aria-label="...">...</div>
</div>

<table class="table table-hover" id="tabelagerente">
<thead>
	<tr>
	<th>Code</th>
	<th width="50">View</th>
	<th>Descrição</th>
	<th>Validade</th>
	<th>Grupo</th>
	<th class="text-center">Quantidade</th>
	<th>Ações</th>
	</tr>
</thead>
  <tbody>
  	<?php $lista = $this->estoque->get_all($this->session->userdata('user_id_empresa'))->result();
			foreach($lista as $estoque): ?>
  	<tr>
  		<td><?php echo $estoque->id ?></td>
  		<td><div class="col-md-7 thumbnail"><img src="<?php echo base_url('uploads/produtos/' . $estoque -> thumblr); ?>" /></div></td>
  		<td><?php echo $estoque->descricao ?></td>
  		<td><?php echo arruma_data($estoque->data_validade) ?></td>
  		<td><?php echo $estoque->nome ?></td>
  		<td class="text-center"><?php echo $estoque->quantidade ?></td>

  		<td>
  			<!-- Split button -->
<div class="btn-group">
  <button type="button" class="btn btn-default">Ações</button>
  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="caret"></span>
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <ul class="dropdown-menu">
    <li><a href="#">Action</a></li>
    <li><a href="#">Another action</a></li>
    <li><a href="#">Something else here</a></li>
    <li role="separator" class="divider"></li>
    <li><a href="#">Separated link</a></li>
  </ul>
</div>
  		</td>
  	</tr>
  	<?php endforeach; ?>
  </tbody>
</table>
	</div>
</div>
</div>
</div>

