<?php
if (!defined('BASEPATH'))exit('No direct script access allowed');?>
<div class="container">
<div class="col-md-12  login">
<div class="row">
<div class="col-md-8 col-md-offset-2">
<div class="row"><?php echo breadcrumb(); ?></div>
<table class="table table-hover" id="tabelagerente">
<thead>
	<tr>
	<th>Code</th>
	<th>Descrição</th>
	<th>Ações</th>
	</tr>
</thead>
  <tbody>
  	<?php $lista = $this->grupo->get_all()->result();
			foreach($lista as $grupo):
  ?>
  	<tr>
  		<td><?php echo $grupo->id ?></td>
  		<td><?php echo $grupo->nome ?></td>
  		<td>
  			
  		</td>
  	</tr>
  	<?php endforeach; ?>
  </tbody>
</table>
	</div>
</div>
</div>
</div>

