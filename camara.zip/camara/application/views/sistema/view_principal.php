<?php
if (!defined('BASEPATH'))exit('No direct script access allowed');?>
<div class="row">
<div class="col-md-4 col-md-offset-4 login">
<form class="form-horizontal" method="post" action="<?php echo base_url('welcome/login') ?>">

</form>
</div>
</div>

