<?php
if (!defined('BASEPATH'))exit('No direct script access allowed');?>
<div class="row box-login">
	
<div class="col-md-4 col-md-offset-4 login">
<form class="form-horizontal" method="post" action="<?php echo base_url('welcome/login') ?>">
<div class="row">
<div class="col-md-10 col-md-offset-2">
	<?php get_msg('errologin') ?>
</div>
</div>	
  <div class="form-group has-alert">
    <label class="col-sm-2 control-label">Login</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="login" name="login" placeholder="Digete seu nome de usuário">
      <?php erros_validacao('login','login') ?>
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword" class="col-sm-2 control-label">Senha</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" name="senha" id="inputPassword" placeholder="Digite sua senha">
    </div>
  </div>
  <div class="form-group">
  <div class="col-md-10 col-md-offset-2">
  <input type="submit" name="enviar" value="Entrar" class="btn btn-default" />
  <a href="<?php echo base_url() ?>">Esqueceu a senha?</a>
  </div>
  </div>
</form>
</div>
</div>

