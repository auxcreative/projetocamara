<div class=container-fluid">
    <h2><i class="fa fa-calendar"></i>Agenda</h2>
    <br/>
    
</div>

<div class="panel panel-default">
  <!-- Default panel contents -->
  <div class="panel-heading">Panel heading</div>

  <!-- Table -->
  <table class="table table-striped table-responsive">
            <thead>
                <tr>
                    <th class="time">Horário</th>
                    <th class="event">Evento</th>
                    <th class="vereador">Vereador</th>
                </tr>
            </thead>
            <tbody>
                <tr class="agenda-event">
                    <td class="time">14:30 - 17:00</td>
                    <td class="event"></td>
                    <td class="party"><span class="event-party icon-logo-"></span></td>
                </tr>
            </tbody>
        </table>
</div>