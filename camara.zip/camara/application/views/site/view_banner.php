<div class="col-md-12">
<textarea name="candidato" cols="12" id="myTextarea">ESCREVE AQUI O NOME DO PERFIL</textarea>
</div>
