<div class=container-fluid">
<div class="row">
    <h2>Lei de acesso à informação</h2>
    <br/>
    
</div>
</div>
<div class="row">
	<div class="col-md-7 image">
		<div class="row">
			<img src="<?php echo base_url('images/entenda-lai.jpg'); ?>" class="img-responsive" />
		</div>
	</div>
	<div class="col-md-5">
		<div class="panel-default">
			<ul class="list-group">
  <li class="list-group-item"><?php echo anchor('http://planalto.gov.br/ccivil_03/_ato2011-2014/2011/lei/l12527.htm','Lei de acesso à informação') ?></li>
  <li class="list-group-item"><?php echo anchor('http://planalto.gov.br/ccivil_03/leis/2002/l10520.htm','Pregão eletrônico') ?></li>
  <li class="list-group-item"><?php echo anchor('http://planalto.gov.br/ccivil_03/leis/L9784.htm','Lei do processo administrativo') ?></li>
  <li class="list-group-item"><?php echo anchor('http://planalto.gov.br/ccivil_03/leis/l9507.htm','Rito processual do habeas data') ?></li>
  <li class="list-group-item"><?php echo anchor('http://planalto.gov.br/ccivil_03/leis/L8159.htm','Política Nacional de arquivos públicos e privados') ?></li>
</ul>
		</div>
		
	</div>
</div>