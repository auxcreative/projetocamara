/**
 * @author Elesbão Pinto
 */
$(document).ready(function(){
        $(".valorFormato").maskMoney({prefix:'R$ ', thousands:'.', decimal:',', allowZero:true});
});

